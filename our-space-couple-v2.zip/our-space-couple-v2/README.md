# Our Space V2 — 双人专属数字宇宙

视觉升级：星空 Canvas、环境光、玻璃拟态、双人连接主视觉、统计卡片、细节动效、响应式移动端布局。

## 文件
- `index.html` 页面结构
- `style.css` 高级深色 UI
- `app.js` Firebase 登录、双人档案、回忆与留言
- `firestore.rules` 两人 UID 白名单规则

## 配置与部署
1. 在 Firebase Console 创建项目并添加 Web 应用。
2. Authentication → Sign-in method → 启用 Email/Password。
3. Authentication → Users 手动创建两位成员，不开放公开注册。
4. Firestore Database 创建数据库。
5. 把 Firebase Web 配置复制到 `app.js` 的 `firebaseConfig`。
6. 复制两位用户的 UID，替换 `firestore.rules` 中两个 `REPLACE_...` 占位符，并在 Firebase Console 的 Firestore → Rules 发布规则。
7. 部署到 Firebase Hosting、Vercel 或 Netlify。因为使用 ES modules，建议通过 HTTP 托管，不要依赖某些浏览器对 `file://` 的限制。

## 安全
- 不要使用 `allow read, write: if true`。
- 只把两位真实 UID 放入白名单。
- Firebase Web config 不是 Admin 私钥；绝不要把服务账号密钥放进前端。
- 当前图片功能保存图片 URL，不是文件上传。要直接上传手机照片，需要后续接入 Firebase Storage 和 Storage Rules。
- 发布后用第三个未授权账号测试，确认无法读写数据库。
